#!/bin/bash

set -x 

# http://doc.lustre.org/lustre_manual.xhtml
# -P means permanent change
###lctl set_param -P obdfilter.lfsbv-*.brw_size=16
